
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);

// Mode: offline/online via URL ?mode=online
const params = new URLSearchParams(location.search);
const ONLINE = params.get('mode')==='online';
const DATA_URL = ONLINE ? 'data/remote.json' : 'data/local.json';

// Theme & Language
function applyLang(l){ document.documentElement.lang=l; document.documentElement.dir=(l==='ar'?'rtl':'ltr'); localStorage.setItem('lang',l); }
function setMode(m){ document.body.classList.toggle('dark', m==='dark'); localStorage.setItem('mode',m); }
$('#langBtn').onclick=()=>applyLang((document.documentElement.lang||'ar')==='ar'?'en':'ar');
$('#modeBtn').onclick=()=>setMode(document.body.classList.contains('dark')?'light':'dark');
applyLang(localStorage.getItem('lang')||'ar'); setMode(localStorage.getItem('mode')||'light');

// Router
function show(id){ $$('.screen').forEach(s=>s.classList.remove('active')); $('#'+id).classList.add('active');
  $$('.nav-btn').forEach(b=>b.classList.toggle('active', b.dataset.go===id));
  window.scrollTo(0,0); }
document.addEventListener('click',(e)=>{const go=e.target.closest('[data-go]'); if(go) show(go.dataset.go)});
function enterApp(){ show('home'); }

// Load data
let DB={};
async function loadData(){
  try{
    const res = await fetch(DATA_URL);
    DB = await res.json();
    hydrate();
  }catch(e){
    console.warn('Failed to load data', e);
  }
}

function setImg(sel, src){ const el=$(sel); if(el) el.src = src; }

function hydrate(){
  // banners
  setImg('#banner1','assets/images/'+(DB.banners?.[0]||'banner1.jpg'));
  // invest cards
  setImg('#imgSheep','assets/images/sheep.jpg');
  setImg('#imgFruits','assets/images/fruits.jpg');
  // news
  setImg('#news1','assets/images/news1.jpg');
  setImg('#news2','assets/images/news2.jpg');
  // contact
  setImg('#ch1','assets/images/banner2.jpg');
  setImg('#gr1','assets/images/banner3.jpg');
  setImg('#av1','assets/images/avatar1.jpg');
  setImg('#av2','assets/images/avatar2.jpg');

  // lists
  renderList('#animalList', DB.animal, (o)=>openDetail('animal',o.id));
  renderList('#agriList',   DB.agri,   (o)=>openDetail('agri',o.id));

  // wallet
  $('#balance').textContent = (DB.wallet?.balance||0).toLocaleString('ar-IQ')+' د.ع';
  let total=0; const list=$('#assets'); list.innerHTML='';
  (DB.wallet?.assets||[]).forEach(a=>{ total+=a.est; const it=document.createElement('div'); it.className='item';
    it.innerHTML=`<div><b>${a.name}</b> — ${a.qty} <span class="small">(${a.note})</span></div><b style="margin-inline-start:auto">${a.est.toLocaleString('ar-IQ')}</b>`;
    list.appendChild(it);
  });
  $('#assetsTotal').textContent = total.toLocaleString('ar-IQ');
}

function renderList(sel, arr, cb){
  const el=$(sel); el.innerHTML='';
  arr.forEach(o=>{
    const row=document.createElement('div'); row.className='item';
    row.innerHTML = `<img class="thumb" src="assets/images/${o.img}"><div><b>${o.name}</b><div class="small">${o.desc}</div></div>`;
    row.onclick=()=>cb(o);
    el.appendChild(row);
  });
}

// Detail
let backId='invest';
function openDetail(group, id){
  const list=(group==='animal')?DB.animal:DB.agri;
  const o=list.find(x=>x.id===id); if(!o) return;
  backId=(group==='animal')?'animal':'agri';
  $('#dTitle').textContent=o.name;
  setImg('#dImg1','assets/images/'+o.img);
  setImg('#dImg2','assets/images/'+o.img);
  $('#dBadge').textContent=o.badge;
  $('#dDesc').textContent=o.desc;
  const box=$('#specs'); box.innerHTML='';
  (o.specs||[]).forEach(s=>{ const d=document.createElement('div'); d.className='card'; d.innerHTML=`<b>${s[0]}</b><div class="small">${s[1]}</div>`; box.appendChild(d); });
  $('#pricing').innerHTML = `رسوم إيجار: <b>${o.rent||'25,000'}</b> د.ع / شهر • تأمين: <b>${o.deposit||'5%'}</b>`;
  $('#dPrice').textContent = (o.price||0).toLocaleString('ar-IQ');
  $('#afterBuy').style.display='none'; show('detail');
}
$('#buy').onclick=()=>{$('#afterBuy').style.display='grid';};
$('#dep').onclick=()=>alert('الإيداع: ماستر/فيزا/زين كاش (تجريبي)');
$('#wd').onclick=()=>alert('السحب: ماستر/فيزا/زين كاش (تجريبي)');

// Contact tabs
const ctTabs=$$('#contactTabs .tab');
ctTabs.forEach(t=>t.addEventListener('click',()=>{
  ctTabs.forEach(b=>b.classList.remove('active')); t.classList.add('active');
  ['channels','groups','chats'].forEach(id=>$('#'+id).style.display='none');
  $('#'+t.dataset.target).style.display='block';
}));
$('#channels').style.display='block';

loadData();
